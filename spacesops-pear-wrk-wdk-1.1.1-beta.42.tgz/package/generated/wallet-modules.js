/**
 * Auto-generated file - DO NOT EDIT MANUALLY
 * Generated from schema.json by scripts/generate-wallet-modules.js
 * 
 * This file contains all static require() statements for wallet modules
 * to ensure proper bundling.
 */

// Preload modules
require('@buildonspark/spark-frost-bare-addon');

// Load WDK core
const wdkModule = require('@tetherto/wdk');
const WDK = wdkModule.default || wdkModule.WDK || wdkModule;

// Load wallet modules
const evmErc4337Module = require('@tetherto/wdk-wallet-evm-erc-4337');
const WalletManagerEvmErc4337 = evmErc4337Module.default || evmErc4337Module;
const sparkModule = require('@tetherto/wdk-wallet-spark');
const WalletManagerSpark = sparkModule.default || sparkModule;
const btcModule = require('@spacesops/wdk-wallet-btc');
const WalletManagerBtc = btcModule.default || btcModule;

// Map networks to wallet managers
const walletManagers = {};
walletManagers['ethereum'] = WalletManagerEvmErc4337;
walletManagers['polygon'] = WalletManagerEvmErc4337;
walletManagers['arbitrum'] = WalletManagerEvmErc4337;
walletManagers['plasma'] = WalletManagerEvmErc4337;
walletManagers['sepolia'] = WalletManagerEvmErc4337;
walletManagers['spark'] = WalletManagerSpark;
walletManagers['bitcoin'] = WalletManagerBtc;

// Export everything
module.exports = {
  WDK,
  walletManagers,
  requiredNetworks: ["ethereum","polygon","arbitrum","plasma","sepolia","spark","bitcoin"]
};
